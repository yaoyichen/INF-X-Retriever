INF-X-Retriever + Chunk-Max: BRIGHT long-document scores
Validated 2026-10-09. Self-reported; pending leaderboard submission/acceptance.
Average Recall@1 x 100: 60.9635. Eight datasets, 861 queries.

Contents:
- scores/<task>.json: original document IDs and top-1000 scores
- validation.json: metrics, dataset revision, and score SHA-256 checksums
- method.json: inference configuration and query-rewrite provenance
- validate_long_submission.py: independent score validator

Verify after extraction (no inference API or GPU needed):
  pip install datasets pytrec_eval
  python validate_long_submission.py --scores scores --expected validation.json --report /tmp/bright-long-validation.json

The reported scores were generated using the internal serving configuration.
Full score parity with the public local-HF runner has not been established.
